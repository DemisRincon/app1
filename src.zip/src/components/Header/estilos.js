import styled from "styled-components";

export const HeaderContainer = styled.header`
    background-color: #282c34;
    min-height: 60px;
    display: flex;
    flex-direction: row;
    align-items: center;
    justify-content: space-between;
    color: white;
    width: 100%;
    height: 60px;
`;

export const HeaderSampleSubContainer = styled.div`
    background-color: red;
    height: 100%;
    min-width: 10%;
`;

export const MenuContainer = styled(HeaderSampleSubContainer)`

`;
export const SearchBarContainer = styled(HeaderSampleSubContainer)`
    width: 60%;
`;
export const NotificationContainer = styled(HeaderSampleSubContainer)`

`;