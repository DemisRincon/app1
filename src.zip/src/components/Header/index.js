import React from 'react'
import { HeaderContainer, MenuContainer, NotificationContainer, SearchBarContainer } from './estilos'
function Header() {
  return (
    <HeaderContainer>
        <MenuContainer>menu</MenuContainer>
        <SearchBarContainer>search</SearchBarContainer>
        <NotificationContainer>noti</NotificationContainer>
    </HeaderContainer>
  )
}

export default Header