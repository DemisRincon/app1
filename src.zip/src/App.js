import Header from "./components/Header";
import {  MainContainer } from "./components/styled";

function App() {
  return (
    <MainContainer>
      <Header />
    </MainContainer>
  );
}

export default App;
